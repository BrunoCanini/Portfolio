<?php
    return ['HTML', 'CSS', 'SASS', 'JS', 'PHP', 'LARAVEL', 'VITE', 'VUEJS', 'BOOTSTRAP', 'TAILWIND', 'AXIOS', 'NODEJS'];
?>
